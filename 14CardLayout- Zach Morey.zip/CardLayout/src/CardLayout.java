import javax.swing.JOptionPane;

public class CardLayout {

	public static void main(String[] args) 
	{
		JOptionPane.showMessageDialog(null, "Zach Morey\n297 Halsey Ave. SE\nBuffalo MN 55313\nHome Number: 763-772-2182\nWork Number: 763-113-1389");

	}

}
