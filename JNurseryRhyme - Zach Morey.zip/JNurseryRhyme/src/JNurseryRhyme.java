import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class JNurseryRhyme {
//Website: http://www.nurseryrhymes.org/a-tisket-a-tasket.html
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame aFrame = new JFrame("Hello");
		aFrame.setSize(500, 500);
		aFrame.setTitle("My frame! (not urs)");
		aFrame.setVisible(true);
		aFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel label = new JLabel("A-tisket, a-tasket - A green and yellow basket - I wrote a letter to my love - And on the way I dropped it - I dropped it - I dropped it - Yes, on the way I dropped it A little boy he picked it up - and put it in his pocket.");
		Font headlineFont = new Font("Arial", Font.BOLD, 14);
		label.setFont(headlineFont);
		aFrame.add(label);
		aFrame.setLocationRelativeTo(null);
	}

}
