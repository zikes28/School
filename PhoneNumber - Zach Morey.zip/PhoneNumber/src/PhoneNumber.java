import javax.swing.JOptionPane;

public class PhoneNumber {

	public static void main(String[] args) {
		
		String number = JOptionPane.showInputDialog(null, "Enter a phone number [ (nnn)-nnn-nnn ]: ");
		String area = number.substring(1,4);
		String prefix = number.substring(6,9);
		String n = number.substring(10,14);
		
		JOptionPane.showMessageDialog(null, "Area Code = " + area + "\nPreix = " +
				prefix + "\nNumber = " + n);
		
	}

}
