import java.awt.*;
import javax.swing.*;

public class JFrame6 {
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame aFrame = new JFrame("Hello");
		aFrame.setSize(500, 500);
		aFrame.setTitle("My frame! (not urs)");
		aFrame.setVisible(true);
		aFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel label = new JLabel("FALLOUT 5!");
		label.setVisible(true);
		JLabel label2 = new JLabel("whaaaaa????");
		aFrame.setLayout(new FlowLayout());
		aFrame.add(label);
		aFrame.add(label2);
		Font headlineFont = new Font("Arial", Font.BOLD, 36);
		label.setFont(headlineFont);
		aFrame.add(label);
		aFrame.setLocationRelativeTo(null);
	}
}
