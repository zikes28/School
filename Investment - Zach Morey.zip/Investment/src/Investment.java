import java.text.NumberFormat;
import java.util.Scanner;

public class Investment 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		
		double investment;
		double yrsInvestment;
		double anualReturn = 0.08;
		double interestRate;
		int i = 1;
		
		//introducing currency type
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
		
		do
		{
			//investment prompt
			System.out.print("Invesment amount: ");
			investment = keyboard.nextInt();
		
			//years prompt
			System.out.print("Years of investment: ");
			yrsInvestment = keyboard.nextInt();
			
			//interest rate prompt
			System.out.print("Interest rate (percentage): ");
			interestRate = keyboard.nextInt();
			
				//ANSWER (money earned) 
				double moneyEarned = ((anualReturn*investment*yrsInvestment)-((interestRate*investment)/100));
		
					if(investment==0 || yrsInvestment==0)
						System.out.println("****try numbers other than 0 bro****\n");
					else
						System.out.println("Money Earned: " + (fmt.format(moneyEarned))+ "\n--------------------------------------\n       Try it again! If you dare...\n");
			i++;
		}while(i<=20);
				
	}

}
