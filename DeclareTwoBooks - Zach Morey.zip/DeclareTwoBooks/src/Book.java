
public class Book 
{
	private String title;
	private int quanity;
	private double price;
	
	public String getTitle()
	{
		return title;
	}
	
	public void setTitle(String newTitle)
	{
		title = newTitle;
	}
	
	public int getquanity()
	{
		return quanity;
	}
	
	public void setQuanity(int newQuanity)
	{
		quanity = newQuanity;
	}
	
	public int getQuanity()
	{
		return quanity;
	}
	
	public void setPrice(double newPrice)
	{
		price = newPrice;
	}

	public double getPrice()
	{
		return price;
	}
}
