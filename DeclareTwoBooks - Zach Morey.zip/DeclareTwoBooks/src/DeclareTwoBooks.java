
public class DeclareTwoBooks 
{
	public static void main(String[] args) 
	{
		Book first = new Book();
		Book second = new Book();
		
		first.setTitle("Yep");
		first.setQuanity(42);
		first.setPrice(30.20);
		
		second.setTitle("Coolness");
		second.setQuanity(40);
		second.setPrice(20.11);
		
		System.out.println("First Book: " + first.getTitle() + "\nQuanity: " + first.getquanity() + "\nPrice: " + first.getPrice());
		System.out.println("\nSecond Book: " + second.getTitle() + "\nQuanity: " + second.getquanity() + "\nPrice: " + second.getPrice());
		
	}
}
