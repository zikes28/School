
public class DeclareTwoStudents 

{

	public static void main(String[] args) 
	{
		Student trad = new Student();
		Student focus = new Student();
		
		trad.setStuNum(123);
		focus.setStuNum(789);
		
		System.out.println("The trad's number is " +
				trad.getStuNum() + " and the focus's number is " +
				focus.getStuNum());
		
	}

}

