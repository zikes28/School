
public class Student 
{
	private int stuNum;
	private String stuLastName;
	private String stuFirstName;
	private double stuGPA;
	
	public int getStuNum()
	{
		return stuNum;
	}
	
	public void setStuNum(int stu)
	{
		stuNum = stu;
	}
	
	public String getStuLastName()
	{
		return stuLastName;
	}
	
	public void setStuLastName(String name)
	{
		stuLastName = name;
	}
	
	public String getStuFirstName()
	{
		return stuFirstName;
	}
	
	public void setStuFirstName(String name)
	{
		stuFirstName = name;
	}
	
	public double getStuGPA()
	{
		return stuGPA;
	}

	public void setStuGPA(double gpa)
	{
		stuGPA = gpa;
	}

}
