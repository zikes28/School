import javax.swing.JOptionPane;

public class Eggs 
{

	public static void main(String[] args) 
	{
		//Declare String
		String NumberOfEggs;
		NumberOfEggs = JOptionPane.showInputDialog(null, "Number of eggs:");
		
		//convert NumberOfEggs to [int numberOfEggs]
		int numberOfEggs = Integer.parseInt(NumberOfEggs);
		
		//transfer to - "PassThrough" Method
		PassThrough(numberOfEggs);
	}
	public static void PassThrough(int numberOfEggs)
	{
		//Calculating dozons and remainder
		int Dozon = 12;
		int intoDozons = numberOfEggs/Dozon;
		int remainder = numberOfEggs-intoDozons*12;  
		
		//display output
		JOptionPane.showMessageDialog(null, intoDozons + " full dozon (with " + remainder + " eggs remaining)");
	}

}
