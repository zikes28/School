import javax.swing.JFrame;
public class JFrame1 {
	public static void main(String[] args){
		JFrame firstFrame = new JFrame("Hello");
		firstFrame.setSize(200, 100);
		firstFrame.setTitle("My frame");
		firstFrame.setVisible(true);
	}
}
