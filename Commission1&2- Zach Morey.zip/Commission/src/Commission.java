import javax.swing.JOptionPane;

public class Commission 
{

	public static void main(String[] args) 
	{
		//declaring strings
		String strSales;
		String strCommissionrt;
		String strIntCommissionrt;
		
		//connecting strings
		strSales = JOptionPane.showInputDialog(null, "Sales amount: ");
		double sales = Double.parseDouble(strSales);
		
		strCommissionrt = JOptionPane.showInputDialog(null, "Commission Rate (input decimal): ");
		double commissionrt = Double.parseDouble(strCommissionrt);
		
		//send to decimal commission rate
		computeCommission(sales, commissionrt);
		
		strIntCommissionrt = JOptionPane.showInputDialog(null, "Commission Rate (input integer): ");
		int intCommissionrt = Integer.parseInt(strIntCommissionrt);
		
		//Integer commission rate
		computeCommission(sales, intCommissionrt);
		 
		//send to 7.5% commission rate
		computeCommission(sales);
		
	}
		
	public static void computeCommission(double sales, double commissionrt)
	{
		//decimal commission rate output
		JOptionPane.showMessageDialog(null, "Commission: " + sales*commissionrt);
	}
	public static void computeCommission(double sales, int intCommissionrt)
	{
		//integer comrate output
		JOptionPane.showMessageDialog(null, "Commission: " + sales*(intCommissionrt/100.0));
	}
	public static void computeCommission(double sales)
	{
		//7.5% rate output
		JOptionPane.showMessageDialog(null, "Commission at a 7.5% rate:\n " + sales*0.075);
	}
}
