import java.text.NumberFormat;

import javax.swing.JOptionPane;

public class Calculator 
{

	public static void main(String[] args) 
	
	{
		//declaring price strings
		String prodPrice;
		String comRate;
		String discount;
		
		//Input Boxes for price, Commission rate and discount rate 
		prodPrice = JOptionPane.showInputDialog(null, "Product's Price: ");
		comRate = JOptionPane.showInputDialog(null, "Salesperson's Commision Percentage: ");
		discount = JOptionPane.showInputDialog(null, "Discount Percentage: ");
		
		//converting strings to doubles
		double DubprodPrice = Double.parseDouble(prodPrice); 
		double DubcomRate = Double.parseDouble(comRate);
		double Dubdiscount = Double.parseDouble(discount);
		
		//sending program to Calc Method
		Calc(DubprodPrice, DubcomRate, Dubdiscount);
	}
	
	public static void Calc(double DubprodPrice, double DubcomRate, double Dubdiscount)
	
	{	
		//calculations
		double prodPricePlusCom = (DubprodPrice+(DubprodPrice*(DubcomRate/100)));
		double prodFinalPrice = prodPricePlusCom-(prodPricePlusCom*(Dubdiscount/100));
		
		//declaring currency format (used in next line)
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
		
		//Displaying final price
		JOptionPane.showMessageDialog(null, "Final Price = " + fmt.format(prodFinalPrice));
	}

	
}