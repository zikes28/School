import java.util.Scanner;

public class SalonReport 
{

	public static void main(String[] args) 
	{
		String salon[][] = { 
				{"cut", "8.00", "15"},
				{"shampoo", "4.00", "10"},
				{"manicure", "18.00", "30"},
				{"style", "48.00", "55"},
				{"permanent", "18.00", "35"},
				{"trim","6.00","5"}
		};
		boolean done = false;
		Scanner keyboard = new Scanner(System.in);
		
		for(int i = 0; i<5; i++)
			System.out.println("*Service: " + salon[i][0] + " *Price: " + salon[i][1] + " *Time: " +salon[i][2]);
		
		while(done==false){
		System.out.println("\n         Prefered sort order (alphabetical, price, or time): ");
		String input = keyboard.nextLine();
		
		switch(input) {
		case "alphabetical":
			System.out.println("Service: " + salon[0][0] + " Price: " + salon[0][1] + " Time: " +salon[0][2] + "\n" +"Service: " + salon[2][0] + " Price: " + salon[2][1] + " Time: " +salon[2][2] + "\n" +"Service: " + salon[4][0] + " Price: " + salon[4][1] + " Time: " +salon[4][2] + "\n" +"Service: " + salon[1][0] + " Price: " + salon[1][1] + " Time: " +salon[1][2] + "\n" +"Service: " + salon[3][0] + " Price: " + salon[3][1] + " Time: " +salon[3][2] + "\n" +"Service: " + salon[5][0] + " Price: " + salon[5][1] + " Time: " +salon[5][2] + "\n"); 
			break;
		case "price":
			System.out.println("Service: " + salon[1][0] + " Price: " + salon[1][1] + " Time: " +salon[1][2] + "\n" +"Service: " + salon[5][0] + " Price: " + salon[5][1] + " Time: " +salon[5][2] + "\n" +"Service: " + salon[0][0] + " Price: " + salon[0][1] + " Time: " +salon[0][2] + "\n" +"Service: " + salon[4][0] + " Price: " + salon[4][1] + " Time: " +salon[4][2] + "\n" +"Service: " + salon[2][0] + " Price: " + salon[2][1] + " Time: " +salon[2][2] + "\n" +"Service: " + salon[3][0] + " Price: " + salon[3][1] + " Time: " +salon[3][2] + "\n"); 
			break;
		case "Time":
			System.out.println("Service: " + salon[5][0] + " Price: " + salon[5][1] + " Time: " +salon[5][2] + "\n" +"Service: " + salon[1][0] + " Price: " + salon[1][1] + " Time: " +salon[1][2] + "\n" +"Service: " + salon[0][0] + " Price: " + salon[0][1] + " Time: " +salon[0][2] + "\n" +"Service: " + salon[2][0] + " Price: " + salon[2][1] + " Time: " +salon[2][2] + "\n" +"Service: " + salon[4][0] + " Price: " + salon[4][1] + " Time: " +salon[4][2] + "\n" +"Service: " + salon[3][0] + " Price: " + salon[3][1] + " Time: " +salon[3][2] + "\n"); 
			break;
		}
	}
	}
}
