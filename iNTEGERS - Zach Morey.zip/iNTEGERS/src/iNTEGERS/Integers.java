package iNTEGERS;

public class Integers 
{
	public static void main(String[] args) 
	{
		int[] tenMult = {10, 20, 30, 40, 50};
		int sum=0, mean;
		
		System.out.println("First to last: ");
		for(int i=0; i<5; i++)
			System.out.println(tenMult[i]);
		
		System.out.println("\nLast to first: ");
		for(int i=4; i>=0; i--)
			System.out.println(tenMult[i]);
		
		System.out.println("\nSum: ");
		for(int i=0; i<5; i++)
			sum+=tenMult[i];
		System.out.println(sum);
		
		System.out.println("\nMean: ");
		System.out.println(sum/5);
	}
}
