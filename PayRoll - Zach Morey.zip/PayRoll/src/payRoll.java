import java.text.NumberFormat;

import javax.swing.JOptionPane;

public class payRoll
{

	public static void main(String[] args)
	{
				//declaring Strings
				String hRateOfPay;
				String nOfHoursWorked;
				
				//Input-Dialog boxes
				hRateOfPay = JOptionPane.showInputDialog(null,"Input your hourly rate of pay:");
				nOfHoursWorked = JOptionPane.showInputDialog(null, "Input the number of hours you have worked:");
				
				//converting string vars to ints
				int InthRateOfPay = Integer.parseInt(hRateOfPay);
				int IntnOfHoursWorked = Integer.parseInt(nOfHoursWorked);
				
				//Introducing number vars + some maths
				double Tax = 0.15;
				int GrossPay = InthRateOfPay*IntnOfHoursWorked;
				double TaxOnGrossPay = GrossPay*Tax;
				double NetPay = GrossPay-TaxOnGrossPay;
				
				//Introducing Currency type
				NumberFormat fmt = NumberFormat.getCurrencyInstance();
				
				//calculation and output
				JOptionPane.showMessageDialog(null, "Gross Pay: " + (fmt.format(GrossPay)) + "\nWitholding Tax: " + (fmt.format(TaxOnGrossPay)) + "\nNet Pay: " + (fmt.format(NetPay)));
	}

}
