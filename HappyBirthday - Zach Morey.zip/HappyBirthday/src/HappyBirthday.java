import javax.swing.JOptionPane;

public class HappyBirthday 
{

	public static void main(String[] args) 
	{
		StringBuilder greeting = new StringBuilder("Happy");
		greeting.append(" Birthday");
		String date = JOptionPane.showInputDialog(null, "Input year born: ");
		int intDate = Integer.parseInt(date);
		
		int year = 2017;
		int newAge = year-intDate;
		
		greeting.insert(6,newAge + "th ");
		
		JOptionPane.showMessageDialog(null, greeting);
	}

}
