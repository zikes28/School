import javax.swing.JOptionPane;

public class PizzaChoice
{

	public static void main(String[] args)
	{	
		double rate[] = {6.99, 8.99, 12.50, 15.00};
		String input1[] = {"S","M","L","X"};
		String input2 = JOptionPane.showInputDialog(null, "Select pizza size (S, M, L, X): ").toUpperCase();
		for(int i = 0; i<=input2.length(); i++)
		{
			if(input2.equals(input1[i]))
				JOptionPane.showMessageDialog(null, "$" + rate[i]);
		}	
	}

}
