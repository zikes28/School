import javax.swing.JOptionPane;

public class CityStateZip {

	public static void main(String[] args)
	{
		String address = JOptionPane.showInputDialog(null, "Input city, state zip - in that format: ");
		int space = address.indexOf(" ");
		int comma = address.indexOf(",");
		int length = address.length();
		
		JOptionPane.showMessageDialog(null, 
		"-- City = " 
		+ address.substring(0, space-1) 
		+ "\n-- State =  "
		+ address.substring(comma+2, length-6) 
		+ "\n-- Zip = " 
		+ address.substring(length-5, length));
	}
		
		
		

		

}
