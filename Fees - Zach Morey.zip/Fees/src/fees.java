import java.text.NumberFormat;

import javax.swing.JOptionPane;

public class fees 
{
	
	public static void main(String[] args)
	
	{
		String cHours;
		String priceOfBooks;
		
		//Input-Dialog boxes
		cHours = JOptionPane.showInputDialog(null,"Input your amount of credit hours:");
		priceOfBooks = JOptionPane.showInputDialog(null, "Input the amount of money you spent on books:");
		
		//converting string vars to ints
		int IntcHours = Integer.parseInt(cHours);
		int IntpriceOfBooks = Integer.parseInt(priceOfBooks);
		
		//Introducing cost vars
		int PricePerC = 85;
		int AthleticFee = 65;
		int TotalFees = (IntcHours*PricePerC)+IntpriceOfBooks+AthleticFee;
		
		//Introducing Currency type
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
		
		//calculation and output
		JOptionPane.showMessageDialog(null, "Your total fee is " + (fmt.format(TotalFees)));
	}
	

}
