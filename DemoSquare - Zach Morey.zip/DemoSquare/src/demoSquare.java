
public class demoSquare {
	public static void main(String[] args){
	Square circle = new Square(5,6,0);
	Cube sphere = new Cube(3,4,5,0);
		System.out.println("The SQUARE has a width of " + circle.getWidth() + ", a hieght of " + circle.getHeight() + ", and a surface area of " + circle.computeSurfaceArea() + ".");
		System.out.println("The CUBE has a width of " + sphere.getWidth() + ", a height of " + sphere.getHeight() + ", a depth of " + sphere.getDepth() + ", and a surface area of " + sphere.computeSurfaceArea() + ".");
	}
}
