
public class Cube {
	private int width;
	private int height;
	private int surfaceArea;
	private int depth;
	
	public Cube(int w, int h, int d, int sA){
		width = w;
		height = h;
		depth = d;
		surfaceArea = sA;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
	public int getDepth(){
		return depth;
	}
	public int getSurfaceArea(){
		return surfaceArea;
}
	public int computeSurfaceArea(){
		surfaceArea = width*height*depth;
		return surfaceArea;
}
}