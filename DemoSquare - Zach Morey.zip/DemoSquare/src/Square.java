
public class Square {
	private int width;
	private int height;
	private int surfaceArea;
	
	public Square(int w, int h, int sA){
		width = w;
		height = h;
		surfaceArea = sA;
	}
	public int getWidth(){
		return width;
	}
	public int getHeight(){
		return height;
	}
	public int getSurfaceArea(){
		return surfaceArea;
}
	public int computeSurfaceArea(){
		surfaceArea = width*height;
		return surfaceArea;
	}
}
