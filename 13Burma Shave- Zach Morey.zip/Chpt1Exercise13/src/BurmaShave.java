import javax.swing.JOptionPane;

public class BurmaShave {

	public static void main(String[] args) 
	{
		JOptionPane.showMessageDialog(null, "His cheek Was rough");
		JOptionPane.showMessageDialog(null, "His chick vamoosed");
		JOptionPane.showMessageDialog(null, "and now she won't");
		JOptionPane.showMessageDialog(null, "Come Home to roost");
		JOptionPane.showMessageDialog(null, "Burma Shave");
	}

}
