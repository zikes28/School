package calcTwinsTix;

import javax.swing.JOptionPane;

public class calcTwinsTix {

	public static void main(String[] args) 
	{
		
	//enter number of twins tix- convert response from string to int	
	//75 PER TIX- processing fee==20- sales tax= 0.7
		int pricePerTicket = 75;
		int processingFee = 20;
		double salesTax = 0.07;
		double total,subTotal;	
		String result;
		result = JOptionPane.showInputDialog(null, "Number of Twins tickets:");
		int intResult = Integer.parseInt(result);
		subTotal = (intResult*pricePerTicket)+processingFee;
		total = subTotal+(subTotal*salesTax);
		

		JOptionPane.showMessageDialog(null, "$" + total);

	}

}
