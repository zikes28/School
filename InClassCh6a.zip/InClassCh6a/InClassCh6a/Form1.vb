﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim secondTotal As Double = Val(TextBox1.Text)
        For i As Integer = 1 To 5
            secondTotal += secondTotal * Val(TextBox2.Text)
            Label4.Text = Label4.Text & "year" & i & ": " & secondTotal & ControlChars.NewLine
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
