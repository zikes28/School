﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim connectionString As String = "Data Source =(local);Initial Catalog=EagleEnterprises;Integrated Security=true"

        Dim strCity As String
        strCity = InputBox("Which city's record do you want to delete?", "Delete a row")

        Using connection As New SqlConnection(connectionString)
            connection.Open()
            MessageBox.Show("Database is open")

            Dim command = New SqlCommand("DELETE FROM Customers WHERE City = '" & strCity & "' ", connection)

            command.ExecuteNonQuery()

            MessageBox.Show("Row deleted")


            connection.Close()
            MessageBox.Show("Database is closed")

        End Using

    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim connectionString As String = "Data Source =(local);Initial Catalog=EagleEnterprises;Integrated Security=true"

        Using connection As New SqlConnection(connectionString)
            'The Using block guarantees the disposal of one or more such resources when your code is finished with them.

            connection.Open()
            MessageBox.Show("Database is open")

            Dim queryString As String = "SELECT CustID, FirstName, LastName, Street, City, State, Zip, Phone, Email FROM dbo.Customers;"

            Dim command As New SqlCommand(queryString, connection)

            Dim dataReader As SqlDataReader = command.ExecuteReader()

            Do While dataReader.Read()  ' Loop through the records in Contacts table
                'outside the bounds of the array
                lblCustID.Text = dataReader.GetString(0)
                lblFirst.Text = dataReader.GetString(1)
                lblLast.Text = dataReader.GetString(2)
                lblStreet.Text = dataReader.GetString(3)
                lblCity.Text = dataReader.GetString(4)
                lblState.Text = dataReader.GetString(5)
                lblZip.Text = dataReader.GetString(6)
                lblPhone.Text = dataReader.GetString(7)
                lblEmail.Text = dataReader.GetString(8)
                MessageBox.Show("Record found")
            Loop

            dataReader.Close()

            connection.Close()
            MessageBox.Show("Database is closed")

        End Using

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        frmAddRow.Show()

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        frmUpdate.Show()

    End Sub
End Class





