﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class frmUpdate
    Dim strCustID As String

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim connectionString As String = "Data Source =(local);Initial Catalog=EagleEnterprises;Integrated Security=true"


        Using connection As New SqlConnection(connectionString)
            connection.Open()
            MessageBox.Show("Database is open")

            Dim Command2 = New SqlCommand("UPDATE Customers SET CustID = '" & txtCustID.Text & "', FirstName = '" & txtFirst.Text & "', LastName = '" & txtLast.Text & "', Street = '" & txtStreet.Text & "', City = '" & txtCity.Text & "', State = '" & txtState.Text & "', Zip = '" & txtZip.Text & "', Phone = '" & txtPhone.Text & "', Email = '" & txtEmail.Text & "' WHERE CustID = '" & txtCustID.Text & "'", connection)

            Command2.ExecuteNonQuery()

            MessageBox.Show("Row updated")

            connection.Close()
            MessageBox.Show("Database is closed")

        End Using

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub frmUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        strCustID = InputBox("Enter CustID to update.")

        Dim connectionString As String = "Data Source =(local);Initial Catalog=EagleEnterprises;Integrated Security=true"


        Using connection As New SqlConnection(connectionString)
            connection.Open()

            Dim queryString As String = "SELECT CustID, FirstName, LastName, Street, City, State, Zip, Phone, Email FROM dbo.Customers WHERE CustID = '" & strCustID & "';"

            Dim command As New SqlCommand(queryString, connection)

            Dim dataReader As SqlDataReader = command.ExecuteReader()

            dataReader.Read()
            txtCustID.Text = dataReader.GetString(0)
            txtFirst.Text = dataReader.GetString(1)
            txtLast.Text = dataReader.GetString(2)
            txtStreet.Text = dataReader.GetString(3)
            txtCity.Text = dataReader.GetString(4)
            txtState.Text = dataReader.GetString(5)
            txtZip.Text = dataReader.GetString(6)
            txtPhone.Text = dataReader.GetString(7)
            txtEmail.Text = dataReader.GetString(8)

            dataReader.Close()

            connection.Close()

        End Using


    End Sub
End Class