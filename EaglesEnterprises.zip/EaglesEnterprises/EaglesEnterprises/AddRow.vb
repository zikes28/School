﻿Imports System
Imports System.Data
Imports System.Data.SqlClient
Public Class frmAddRow

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim connectionString As String = "Data Source =(local);Initial Catalog=EagleEnterprises;Integrated Security=true"

        Using connection As New SqlConnection(connectionString)
            connection.Open()
            MessageBox.Show("Database is open")

            Dim Command = New SqlCommand("INSERT INTO Customers (CustID, FirstName, LastName, Street, City, State, Zip, Phone, Email) VALUES ('" & txtCustID.Text & "','" & txtFirst.Text & "','" & txtLast.Text & "','" & txtStreet.Text & "','" & txtCity.Text & "','" & txtState.Text & "','" & txtZip.Text & "','" & txtPhone.Text & "','" & txtEmail.Text & "')", connection)

            command.ExecuteNonQuery()

            MessageBox.Show("Row added")

            connection.Close()
            MessageBox.Show("Database is closed")

        End Using
    End Sub
End Class