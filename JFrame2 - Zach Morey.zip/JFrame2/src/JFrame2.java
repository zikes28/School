import javax.swing.*;

public class JFrame2 {

	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame AFrame = new JFrame("Hello");
		AFrame.setSize(200, 100);
		AFrame.setTitle("My frame! (not urs)");
		AFrame.setVisible(true);
		JLabel label = new JLabel("your mom");
		label.setVisible(true);
	}
}
