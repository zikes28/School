package Exercise6-pg46;

public class Exercise6-pg46 {

	public static void main(String[] args) 
	{System.out.println("Zach Morey\n297 Halsey Ave. SE\nBuffalo, MN 55313"
			+ "");
	

	
	}

	
}
