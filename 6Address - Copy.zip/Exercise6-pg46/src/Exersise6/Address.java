package Exersise6;

public class Address {

	public static void main(String[] args) 
	{
		System.out.println("Zach Morey\n297 Halsey Ave. SE\nBuffalo, MN 55313");
		

	}

}
