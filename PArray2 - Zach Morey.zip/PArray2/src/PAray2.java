import javax.swing.JOptionPane;

public class PAray2
{
	public static void main(String[] args) 
	{
		String abrev[] = {"AL", "CA", "FL", "IA", "IL", "IN", "MI", "MN", "ND", "SD"};
		String name[] = {"Alabama", "California", "Florida", "Iowa", "Illinois", "Indiana", "Michigan","Minnesota", "North Dakota", "South Dakota"};
		String zip[] = {"35801", "90001", "32501", "50301", "60601", "46201", "49036", "55801", "58282", "57401"};
		
		String input = JOptionPane.showInputDialog(null, "Input state abreviation: ").toUpperCase();
		for(int i = 0; i<=abrev.length; i++)
		{
			if(input.equals(abrev[i]))
				JOptionPane.showMessageDialog(null, name[i] + " " + zip[i]);
		}	
		
	}
}
