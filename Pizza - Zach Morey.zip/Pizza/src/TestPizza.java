import java.text.NumberFormat;

public class TestPizza {

	public static void main(String[] args) 
	{
		Pizza top = new Pizza();
		Pizza dmeter = new Pizza();
		Pizza price = new Pizza();
		
		top.setTopping("Sausage, apples, cardboard");
		dmeter.setDiameter(10);
		price.setPrice(9.99);
		
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
		
		System.out.println("\nTopping(s): " +
				top.getTopping() + "\n\nDiameter of Pizza: " +
				dmeter.getDiameter() + " inches" +  "\n\nPrice: " + fmt.format(price.getPrice()));
	}

}
