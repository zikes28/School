
public class Pizza 
{
	String topping;
	int diameter;
	double Price;
public String getTopping()
{
	return topping;
}
public void setTopping(String top)
{
	topping = top;
}
public int getDiameter()
{
	return diameter;
}
public void setDiameter(int dmeter)
{
	diameter = dmeter;
}
public double getPrice()
{
	return Price;
}
public void setPrice(double price)
{
	Price = price;
}

}
