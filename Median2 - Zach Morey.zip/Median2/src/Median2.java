import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JOptionPane;

public class Median2 {

	public static void main(String[] args){
		ArrayList<Double> numbers = new ArrayList<Double>();
		String result = "";
		double val;
		int length;
		
		while(!(result.equals(" ")))
		{
			result = JOptionPane.showInputDialog(null, "Input numbers and find the MEDIAN!!!");
			
			if(result.equals(" "))
			{    }
			else
			{
				val=Double.parseDouble(result);
				numbers.add(val);
			}

		}
		
		Collections.sort(numbers);
		length=numbers.size();
		
		if(length%2==0)
		{
			int middle = length/2;
			double val1=numbers.get(middle-1);
			double val2=numbers.get(middle);
			
			double median=(val1+val2)/2;
			JOptionPane.showMessageDialog(null, "The median is: " + median);
		}
		else
		{
			int middle=length/2;
			double median = numbers.get(middle);
			JOptionPane.showMessageDialog(null, "The median is: " + median);
		}
	}

}
