import javax.swing.JOptionPane;

public class Password
{

	public static void main(String[] args)
	{
		String input;
		int charCounter = 0, digitCounter = 0;
		
		input = JOptionPane.showInputDialog(null, "Input your new password "
				+ "(6-10 charactars with at least 1 digit and 1 letter): ");
		int length = input.length();
		
		for(int i = 0; i<input.length(); i++)
		{ 
			if(Character.isLetter(input.charAt(i)))
					charCounter++;
			if(Character.isDigit(input.charAt(i)))
					digitCounter++;
		}
		String confirm = input + "not input";
		
			while(length<6 || length>10 || charCounter<1 || digitCounter<1 && !confirm.equals(input))
			{
				input = JOptionPane.showInputDialog(null, "Try again smart one. Like, seriously bro? u gonna try dis with me? ME!?\n\n" + "(6-10 charactars with at least 1 digit and 1 letter): ");
				length = input.length();
				
				while(length>=6 && length<=10 && !confirm.equals(input))
				{
					confirm = JOptionPane.showInputDialog(null, "Input your new password to confirm: ");
					if(confirm.equals(input))
						JOptionPane.showMessageDialog(null, "GG bro.\n*gives a thumbs up");
				}
				
			}
			
			while(length>=6 && length<=10 && charCounter>=1 && digitCounter>=1 && !confirm.equals(input))
			{
				confirm = JOptionPane.showInputDialog(null, "Input your new password to confirm: ");
				if(confirm.equals(input))
					JOptionPane.showMessageDialog(null, "GG bro.\n*gives a thumbs up");
				else
				{
					while(confirm.length()<6 || confirm.length()>10 || length<6 || length>10 && !confirm.equals(input))
					{
						input = JOptionPane.showInputDialog(null, "Try again smart one. Like, seriously bro? u gonna try dis with me? ME!?\n\n" + "(6-10 charactars with at least 1 digit and 1 letter): ");
						length = input.length();
						while(length>=6 && length<=10 && !confirm.equals(input))
						{
							confirm = JOptionPane.showInputDialog(null, "Input your new password to confirm: ");
							if(confirm.equals(input))
								JOptionPane.showMessageDialog(null, "GG bro.\n*gives a thumbs up");
						}
					}
				}
			}
					
	}

}
