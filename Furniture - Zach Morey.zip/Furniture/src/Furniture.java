import javax.swing.JOptionPane;

public class Furniture
{

	public static void main(String[] args)
	{
		//Declaring input string for wood types
		String wood;
		
		//Attatching values to wood types
		int pine = 100;
		int oak = 225;
		int mahogany = 300;
		int zero = 0;
		
	//Prompting user to input wood type
	wood=JOptionPane.showInputDialog("Furniture Wood type (Choices- Pine, Oak, and Mahogany):  ");
		
	//Making inut not case sensitive
	wood = wood.toLowerCase();
	
	//creating switch
	switch(wood)
	{
	
	//Wood type cases
	case("pine"):
			JOptionPane.showMessageDialog(null, "Pine: $" + pine);
			break;
	case("oak"):
		
		JOptionPane.showMessageDialog(null, "Oak: $" + oak);
		break;
	
	case("mahogany"):
		
		JOptionPane.showMessageDialog(null, "Mahogony: $" + mahogany);
		break;
	//defauly case (what happens if somtin is done wrong)
	default:
		JOptionPane.showMessageDialog(null, "Invalid Input: " + wood + "\n $" + zero);
	}


	}

}
