import javax.swing.JOptionPane;

public class SetUpSite 
{
public static void main(String[] args)
	{
	EventSite first = new EventSite();
	JOptionPane.showMessageDialog(null,  "You selected site number " + first.getSiteNumber());
	
		String siteNumberString;
		int siteNumber;
		
		siteNumberString = JOptionPane.showInputDialog(null, "Enter site number: ", "Site dialog", JOptionPane.INFORMATION_MESSAGE);
		
		siteNumber = Integer.parseInt(siteNumberString);
		first.setSiteNumber(siteNumber);
		
		JOptionPane.showMessageDialog(null, "You selected site number " + first.getSiteNumber());		
	}
}
