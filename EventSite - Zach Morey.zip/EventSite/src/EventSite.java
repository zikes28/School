
public class EventSite 
{
	private int siteNumber;

	public EventSite()
	{
	siteNumber = 890;
	}
	
	public int getSiteNumber()
	{
	return siteNumber;
	}

	public void setSiteNumber(int n)
	{
		siteNumber = n;
	}

}
