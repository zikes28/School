import javax.swing.JOptionPane;
public class Room2
{

	public static void main(String[] args) 
	
	{
		//Declare Vars
		String Length;
		String Width;
		
		//Input-Dialog boxes
		Length = JOptionPane.showInputDialog(null,"input length:");
		Width = JOptionPane.showInputDialog(null, "Input width:");
		
		//converting string vars to ints
		int IntLength = Integer.parseInt(Width);
		int IntWidth = Integer.parseInt(Length);
		
		//calculation and output
		JOptionPane.showMessageDialog(null, "The floor space is " + IntLength*IntWidth + " square feet");
		
	}

	
	
}
