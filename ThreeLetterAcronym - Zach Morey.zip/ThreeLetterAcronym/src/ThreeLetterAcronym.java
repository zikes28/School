import javax.swing.JOptionPane;

public class ThreeLetterAcronym 
{

	public static void main(String[] args) 
	{
		String words;
		String[] word;
		
		words = JOptionPane.showInputDialog(null, "Input 3 words (to be turned into acronym): ");
		word = words.split(" ");
		JOptionPane.showMessageDialog(null, Character.toString(word[0].charAt(0)).toUpperCase() + Character.toString(word[1].charAt(0)).toUpperCase() + Character.toString(word[2].charAt(0)).toUpperCase());
	}

}
