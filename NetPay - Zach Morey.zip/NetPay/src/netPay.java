import java.text.NumberFormat;

import javax.swing.JOptionPane;

public class netPay

{

	public static void main(String[] args) 
	{
		double wage = 18.75;
		double federaltaxrate = 0.22;
		double stateTaxRate = 0.075;
		double grossPay, netpay;
				
		NumberFormat fmt = NumberFormat.getCurrencyInstance();
		
		String Input;
		Input = JOptionPane.showInputDialog(null, "How Many Hours Worked?");
		int hours = Integer.parseInt(Input);
		grossPay = hours*wage;
		netpay = grossPay-((grossPay*federaltaxrate)+(grossPay*stateTaxRate));
		
		JOptionPane.showMessageDialog(null, "Gross Pay=" + (fmt.format(grossPay)) + "\nFederal Tax Amount=" + (fmt.format(federaltaxrate*grossPay) + "\nState Tax Amount=" + (fmt.format(stateTaxRate*grossPay)) + "\nNetPay=" + (fmt.format(netpay))));
				
	}

}
