import javax.swing.JOptionPane;

public class PArray 
{

	public static void main(String[] args) 
	{
		double rate[] = {100,200,300,400};
		int input = Integer.parseInt(JOptionPane.showInputDialog(null, "Input year in school (1,2,3,4): "));
		JOptionPane.showMessageDialog(null, rate[input-1]);
	}

}
