import javax.swing.JOptionPane;

public class testMethods 
{

	public static void main(String[] args)
	{
		//declaring random variables that match up with their names
		int Six = 6;
		int Nine = 9;
		//sending
		DisplayIt(Six, Nine);
	}
public static void DisplayIt(int Six, int Nine)
	{
		//displaying
		JOptionPane.showMessageDialog(null, "Variable One: " + Six + "\nVariable Two: " + Nine);
		//sending
		DisplayItTimesTwo(Six, Nine);
	}
public static void DisplayItTimesTwo(int Six, int Nine)
	{
		//declaring 2 for the double
		int Two = 2;
		//displaying
		JOptionPane.showMessageDialog(null, "Variable One times two: " + Six*Two + "\nVariable Two times two: " + Nine*Two);
		//sending
		DisplayItPlusOneHundred(Six, Nine);
	}
public static void DisplayItPlusOneHundred(int Six, int Nine)
	{
		//declaring for ease
		int OneHundredAdditionSix = 100+Six;
		int OneHundredAdditionNine = 100+Nine;
		//displaying final
		JOptionPane.showMessageDialog(null, "Variable One plus onehundred: " + OneHundredAdditionSix + "\nVariable Two plus onehundred: " + OneHundredAdditionNine);
	}

}
