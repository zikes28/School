import javax.swing.JOptionPane;

public class Pay
{

	public static void main(String[] args) 
	{
		//declaring strings
		String strHrsWorked;
		String strPayRate;
		String strWHoldingRt;
		String strGrossPay;
		String strNetPay;
		
	//attatching strings
		strHrsWorked = JOptionPane.showInputDialog(null, "Hours Worked: ");
			//converting to double
		double hrsWorked = Double.parseDouble(strHrsWorked);
		
		strPayRate = JOptionPane.showInputDialog(null, "Pay per hour: ");
		double payRate = Double.parseDouble(strPayRate);
		
		strWHoldingRt = JOptionPane.showInputDialog(null, "With Holding Rate Percentage: ");
		double wHoldingRt = Double.parseDouble(strWHoldingRt);
		
		//send to netpay based on answers
		computeNetPay(hrsWorked, payRate, wHoldingRt);
		 
		//Netpay based on hrs and payrt and 15% withholding rate
		computeNetPay(hrsWorked, payRate);
		
		//netpay based on hrs worked with 15% withholdingRT and 5.85 pay rate
		computeNetPay(hrsWorked);
		
	}
	public static void computeNetPay(double hrsWorked, double payRate, double wHoldingRt)
	{
		//NetPay output- based on input
		JOptionPane.showMessageDialog(null, "Net Pay = " + (hrsWorked*payRate-((hrsWorked*payRate)*(wHoldingRt/100))));
	}
	public static void computeNetPay(double hrsWorked, double payRate)
	{
		//NetPay output based on input with 15% set withholding rate
		JOptionPane.showMessageDialog(null, "Net Pay \n(withholding rate of 15%)\n = " + (hrsWorked*payRate-((hrsWorked*payRate)*0.15)));
	}
	public static void computeNetPay(double hrsWorked)
	{
		//NetPay output based on hrsWorked + 15% WitholdingRT and 5.85 PayRate
		JOptionPane.showMessageDialog(null, "Net Pay \n(withholding rate of 15%)\n(hourly rate of pay = 5.85)\n = " + (hrsWorked*5.85-((hrsWorked*5.85)*0.15)));
	}

}
