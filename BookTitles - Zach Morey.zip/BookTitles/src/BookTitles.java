import javax.swing.JOptionPane;

public class BookTitles 
{

	public static void main(String[] args) 
	{
		boolean done = false; 
		String bookTitle[][] = { 
				{"Dont Read Me", "Your Worstnightmare"},
				{"The InvestiGATOR", "Coolio Jenkins"},
				{"All Knowlege Ever", "Ben Shapiro"},
				{"The Book of Power", "Some Wizard"}
							};	
				
				while(done==false)
				{
					String input = JOptionPane.showInputDialog(null, "Input the author's name: ");
					for(int i = 0; i<4; i++)
					{
						if(input.equals(bookTitle[i][1]))
						{
						JOptionPane.showMessageDialog(null, bookTitle[i][1] + " is a fan-freaking-tastic author. He is known for writing : " + bookTitle[i][0] + ". [[It is literally the beeest]] ");
						done=true;
						}
					}
					if(done==false)
						JOptionPane.showMessageDialog(null, "no...");
				}
			
		
		}
	}


