
public class demoBook {

	public static void main(String[] args){
		book b1 = new book("Oranges", 101);
		textBook b2 = new textBook("Apples", 111, 5);
			System.out.println("The first book is " + b1.getBookTitle() + " which has " + b1.getBookPages() + " pages.");
			System.out.println("The second book is " + b2.getTextBookTitle() + " which has " + b2.getTextBookPages() + " pages and a grade " + b2.getGradeLevel() + " reading level.");
	}

}
