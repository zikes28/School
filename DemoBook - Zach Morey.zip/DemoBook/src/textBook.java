
public class textBook {
private int gradeLevel;
private String tbTitle; 
private int tbnumOfPages;
	public textBook(String title, int pages, int gLevel){
		gradeLevel=gLevel;
		tbTitle=title;
		tbnumOfPages=pages;
	}
	public String getTextBookTitle(){
		return tbTitle;
	}
	public int getTextBookPages(){
		return tbnumOfPages;
	}
	public int getGradeLevel(){
		return gradeLevel;
	}
	public int setGradeLevel(){
		return gradeLevel;
	}
}