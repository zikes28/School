
public class book {
private String bTitle; 
private int numOfPages;
	public book(String title, int pages){
		bTitle = title;
		numOfPages = pages;
	}
	public String getBookTitle(){
		return bTitle;
	}
	public int getBookPages(){
		return numOfPages;
	}
	}
