//Name: Zach Morey
//Date: 1/12/17
package hello;

import javax.swing.JOptionPane;

public class Hello {

	public static void main(String[] args) 
	{
		JOptionPane.showMessageDialog(null, "Zach Morey: Wazup Fam");
		//Display: Hello from Zach Morey
	}

}
