import javax.swing.JOptionPane;

public class CountVowels 
{

	public static void main(String[] args) 
	{

	String word = JOptionPane.showInputDialog(null, "Enter an input containing vowels to be counted: ");
	word = word.toLowerCase();
	char index = word.charAt(0);
	
		int counter = 0;
		int i = 0;
		while(i < word.length())
		{ 
			switch(word.charAt(i))
			{
	        case 'a': 
	        	counter++;
	        case 'e': 
	        	counter++;
	        case 'i': 
	        	counter++;
	        case 'o': 
	        	counter++;
	        case 'u': 
	        	counter++;
	            i++;
	            break;
	        default:
	        i++;
			}
		}
		
	JOptionPane.showMessageDialog(null, "Vowel count: " + counter/5);
	
	}	
}