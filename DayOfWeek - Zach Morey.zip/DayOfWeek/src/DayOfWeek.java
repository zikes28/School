import java.util.Scanner;
public class DayOfWeek {
	enum type {monday, tuesday, wednesday, thursday, friday, saturday, sunday}
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Days: ");
		for (type t : type.values())
		System.out.println(" " + t + " " );
		System.out.println("Input a day of the week to check open times:" );
		
		type input = type.valueOf(keyboard.nextLine());
			switch(input) 
			{
			case monday:
				System.out.println(" Open from 9 to 9 on Monday (and every other weekday)");
				break;
			case tuesday:
				System.out.println(" Open from 9 to 9 on Tuesday (and every other weekday)");
				break;
			case wednesday:
				System.out.println(" Open from 9 to 9 on Wednesday (and every other weekday)");
				break;
			case thursday:
				System.out.println(" Open from 9 to 9 on Thursday (and every other weekday)");
				break;
			case friday:
				System.out.println(" Open from 9 to 9 on Friday (and every other weekday)");
				break;
			case saturday:
				System.out.println(" Open from 9 to 6 on Saturday");
				break;
			case sunday:
				System.out.println(" Open from 11 to 5 on Sunday");
				break;
			}
	}

}
