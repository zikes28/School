
public class WeightRateDistance 
{
private String weight;
private String rate;
private String distance;

public void WeightRateDistance(String wght, String rt, String dstnce)
{
	weight = wght;
	rate = rt;
	distance = dstnce;
	
	}
public void display()
{
	System.out.println(weight);
	System.out.println(rate);
	System.out.println(distance);
}

}
