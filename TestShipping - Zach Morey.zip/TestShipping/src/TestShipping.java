
public class TestShipping
{

	public static void main(String[] args) 
	{
		Shipping newShip = new Shipping(1,2,3);
	}

}
