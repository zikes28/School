
public class Shipping 
{
	int weight, rate, distance;

	public Shipping(int w)
	{
		weight = w;
		rate = 0;
		distance = 0;
		System.out.println("weight: " + w);
	}
	public Shipping(int w, int r)
	{
		weight = w;
		rate = r;
		distance = 0;
		System.out.println("weight: " + w + " rate: " + r);
	}
	public Shipping(int w, int r, int d)
	{
		weight = w;
		rate = r;
		distance = d;
		System.out.println("weight: " + w + " rate: " + r + " distance: " + d);
	}
}
