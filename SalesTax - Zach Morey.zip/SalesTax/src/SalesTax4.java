import javax.swing.JOptionPane;

public class SalesTax4
{

	public static void main(String[] args) 
	{
		
		String strSales;
		String strTaxRate;
		
		String intStrTaxRate;
		
		strSales = JOptionPane.showInputDialog(null, "Sales amount: ");
		double sales = Double.parseDouble(strSales);
		
		strTaxRate = JOptionPane.showInputDialog(null, "Tax Rate (input decimal): ");
		double doubTaxRate = Double.parseDouble(strTaxRate);
		
		CalcTax(sales, doubTaxRate);
		
		intStrTaxRate = JOptionPane.showInputDialog(null, "Sales amt (Input integer): ");
		JOptionPane.showInputDialog(null, "Tax Rate (Input integer): " );
	
		int intTaxRate = Integer.parseInt(intStrTaxRate);
		
		CalcTax(sales, intTaxRate);
		
	}
	
	public static void CalcTax(double sales, double doubTaxRate)
	{	
	double SalesTaxAmount = sales*doubTaxRate;
	JOptionPane.showMessageDialog(null, "Total Tax: " + SalesTaxAmount);
	}
	
	public static void CalcTax(double sales, int intTaxRate)
	{	
	double SalesTaxAmount = sales*intTaxRate/100.0;
	JOptionPane.showMessageDialog(null, "Total Tax: " + SalesTaxAmount);
	}

}
