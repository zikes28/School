
public class TryToParseString {

	public static void main(String[] args) {
		String str = "I'm a string!";
		int int1;
		try{
			int1 = Integer.parseInt(str);
		}
		catch(NumberFormatException fail){
			System.out.println("Don't even try to get dat one past me boiiii");
		}
	}
}
