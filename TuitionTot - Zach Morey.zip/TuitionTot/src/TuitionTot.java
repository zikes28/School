import java.text.NumberFormat;

import javax.swing.JOptionPane;
public class TuitionTot
{

	public static void main(String[] args)
	{
		String strYear;
		String strCredits;
		int FR = 200;
		int SO = 225;
		int JR = 250;
		int SR = 300;
		
		strYear=JOptionPane.showInputDialog("Academic Year (Enter: FR, SO, JR, or SR): ");
		strCredits=JOptionPane.showInputDialog("Current Credit Number: ");
		
		int credits = Integer.parseInt(strCredits);
		int tuition = 0;
		
		if(strYear.equals("FR"))
		{
			tuition=credits*FR;
		}
		else if(strYear.equals(SO))
		{
			tuition=credits*SO;
		}
		else if(strYear.equals(JR))
		{
			tuition=credits*JR;
		}
		else if(strYear.equals(SR))
		{
			tuition=credits*SR;
		}
		
		JOptionPane.showMessageDialog(null, "Tuition: " + tuition);
	}
	

}
