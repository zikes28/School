
public class GoToFar {
	public static void main(String[] args) {
		int[] a = {1, 2, 3, 4, 5};
		try {
			for(int i=0; i<7; i++)
				System.out.println(a[i]);
		}
		catch(ArrayIndexOutOfBoundsException mistake){
			System.out.println("Now you've gone too far son!!!\n  but das ok. NO WORRIES!!!");
		}
	} 
}
