import javax.swing.JOptionPane;

class ConvertDateOrg 
{
	public static void main(String[] args)
	{
			String names[] = {"January","Feburary","March","April","May","June","Jully","August","September","October","November","December"}; 
			int[] month3130 = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
			
			String monthNum, yearNum, dayNum;
			int month = -1, day = -1, year = -1, days = 0;
			boolean zero = true;
			
			do {
				String date = JOptionPane.showInputDialog(null, "Enter month, date, and year in this format: --/--/---- ");
				monthNum = date.substring(0,2);
				
					if (monthNum.charAt(0) != '0')
						zero = false;
					
					if (zero == true)
					{
						dayNum = date.substring(3,5);
						yearNum = date.substring(6,10);
						month = Integer.parseInt(monthNum);
						day = Integer.parseInt(dayNum);
						year = Integer.parseInt(yearNum);
					}
					
					else
					{
						monthNum = date.substring(0,1);
						dayNum = date.substring(2,4);
						yearNum = date.substring(5,9);
						month = Integer.parseInt(monthNum);
						day = Integer.parseInt(dayNum);
						year = Integer.parseInt(yearNum);
					}
			   }
			while (month < 1 || month > 12 || day < 1 || day > month3130[month-1]);
			
			for (int i=0;i<=month-1;i++)
			
			days += month3130[i];
			days += day;
			
			JOptionPane.showMessageDialog(null, "Date: (" + names[month-1] + " " + day + ", " + year +")"
					+ "\n   Day in the year = " + "(" + days + ")");
			
	}

}


