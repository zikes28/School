import javax.swing.JOptionPane;

public class StudentIDArray 
{
	public static void main(String[] args) 
	{
			String ids[] = {"1111","2222","3333","4444","5555","6666","7777","8888","9999","1010"};
			String name[] = {"Andersoon","Buffalo","Cat","DoVAKING","Enderman","Funstuffs","Gragnarc the Barbarian","Hidio Kojima","Indiginous","Josh"};
			double grade[] = {4.0,3.2,2.9,3.9,1.7,3.1,3.0,2.2,1.1,2.0};
			boolean done = false;
		
		while(done==false)
		{
			String input = JOptionPane.showInputDialog(null, "Input student ID: ");
			for(int i = 0; i<=ids.length-1; i++)
			{
				if(input.equals(ids[i]))
				{
				JOptionPane.showMessageDialog(null, "Name: " + name[i] + "\nGrade point average =  [" + grade[i] + "]");
				done=true;
				}
			}
			if(done==false)
				JOptionPane.showMessageDialog(null, "*The ID you inputed is not valid you TROLL!*\n   You REALLY want to mess with me kid???");
		}
	}
}