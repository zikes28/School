import java.util.Scanner;

public class Age 
{

	public static void main(String[] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		int age = 101;
		
		
		
		System.out.println("Input Age (must be less than 101): ");

			while(age>100)
		{
				age = keyboard.nextInt();
		}
	int year = 2017;
	int i = 1;
		while(i<=5)
		{
			System.out.println( "year: " + year + " Age: " + age);
			year++;
			age++;
			i++;
		}

			
	}

}
 