
public class Fibonacci 
{

	public static void main(String[] args)
	{
		int counter = 1;
		int counter2 = 1;
		
		for(int i = 0; i<=21; i++)
		{
			int sum = counter2 + counter;
			System.out.println(counter + " + " + counter2 + " = " + sum + " ");
			counter=counter2;
			counter2=sum;
			
		}
	}

}
