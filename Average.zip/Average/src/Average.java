
public class Average 

{

	public static void main(String[] args)
	
	{
		
int test1 = 1;
int test2 = 2;
int test3 = 87;
int test4 = 4;
int test5 = 12;
int total;
double avg; 

total = test1+test2+test3+test4+test5;
avg = (total/5);

System.out.println("Average = " + avg);

	}

}
