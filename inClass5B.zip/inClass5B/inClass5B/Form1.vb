﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim weight = InputBox("weight of car?")
        Dim price = 0
        Select Case weight
            Case < 1000
                price = 25
            Case 1000 To 1999
                price = 50
            Case 2000 To 2499
                price = 85
            Case 2500 To 2999
                price = 125
            Case 3000 To 3999
                price = 200
            Case > 3999
                price = 400
        End Select
        Label1.Text = "your price is $" & price
    End Sub
End Class
