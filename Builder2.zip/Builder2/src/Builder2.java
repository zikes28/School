import javax.swing.JOptionPane;

public class Builder2 
{

	public static void main(String[] args)
	{
		String firstName = "Zachary";
		String middleName = "Ronald";
		String lastName = "Morey";
		
		
		StringBuilder entireName = new StringBuilder(firstName +
				" " + middleName +  " " + lastName);
		JOptionPane.showMessageDialog(null, entireName);
		
		StringBuilder lastFirst = new StringBuilder(lastName + ", " + firstName);
		JOptionPane.showMessageDialog(null, lastFirst);
		
		StringBuilder signiture = new StringBuilder(firstName +
				" " + middleName.substring(0,1) + ". " + lastName);
		JOptionPane.showMessageDialog(null, signiture);
		;
	}

}
