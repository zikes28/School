﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim intCounter As Integer = 1
        Dim dblScore As Double
        Dim dblTotal As Double
        Dim dblAverage As Double
        Dim strInput As String

        strInput = InputBox(“Enter a test score”, “Tests”)

        Do While strInput <> String.Empty
            Double.TryParse(strInput, dblScore)
            dblTotal = dblTotal + dblScore
            intCounter = intCounter + 1
            strInput = InputBox(“Enter a test score”, “Tests”)
        Loop

        dblAverage = dblTotal / intCounter

        lblTotal.Text = dblTotal.ToString
        lblAverage.Text = dblAverage.ToString("N2")
    End Sub
End Class
