import javax.swing.JOptionPane;

public class Admission 
{

	public static void main(String[] args) 
	{
		//declaring strings for grade and test score inputs
		String strHsGrade;
		String strAdmTest;
	//prompting for grade and test score
	strHsGrade=JOptionPane.showInputDialog("High School grade point average: ");
	strAdmTest=JOptionPane.showInputDialog("Admission Test Score: ");
		//converting grade and test score from strings to doubles
		double hsGrade = Double.parseDouble(strHsGrade);
		double admTest = Double.parseDouble(strAdmTest);
	//original acceptance condition
	if(hsGrade>=3 && admTest>=60)
		JOptionPane.showMessageDialog(null, "Accept");
	//second acceptance possibility
	else
		if(hsGrade<3 && admTest>=80)
			JOptionPane.showMessageDialog(null, "Accept");
	//Error if incompatible numbers are proposed 
	else
		if(hsGrade<0 || hsGrade>4 || admTest<0 || admTest>100)
			JOptionPane.showMessageDialog(null, "*****Error*****\n-For grade point average, enter a number between 0 and 4\n-For admission test score, enter a number between 0 and 100");
	//Rejection possibility- grades not good enough
	else
		JOptionPane.showMessageDialog(null, "Reject");
	
	
	}

	
}
