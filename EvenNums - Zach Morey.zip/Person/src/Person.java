import javax.swing.JOptionPane;

public class Person {
	
	public static void main(String[] args) {
		
		String name = JOptionPane.showInputDialog(null, "Enter first and last name: ", "First Last");
		int space = name.indexOf(" ");
		String first = name.substring(0,space);
		String last = name.substring(space+1,name.length());
		JOptionPane.showMessageDialog(null, "Space is at index = " + space +
				"\nFirst name = " + first + "\nLast name = " + last + "\n" +
				last + ", " + first + ".");
		
	}
	
}
