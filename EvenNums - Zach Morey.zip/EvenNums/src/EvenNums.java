

public class EvenNums
{
//This is a bit long but its the only way i could find to do it with spaces and indents between lines and numbers
	public static void main(String[] args)
	{
		//loop control variable
		int i = 1;
		//evens counter
		int evens = 0;
	//loops are individual to put spaces between numbers and to indent lines 	
	while(i<10)
		//adding two to evens every time as welll as a space after
		{System.out.print((evens=evens+2) + " ");
		//adding 1 to control
		i++;
		}
	//if statements are in place for indents. 
	if(i==10)
		{System.out.print( "20\n\n");
		evens=evens+2;
		i++;
		}
	while(i<20)
		{System.out.print((evens=evens+2) + " ");
		i++;
		}
	if(i==20)
		{System.out.println("40\n");
		evens=evens+2;
		i++;
		}
	while(i<30)
		{System.out.print((evens=evens+2) + " ");
		i++;
		}
	if(i==30)
		{System.out.println("60\n");
		evens=evens+2;
		i++;
		}
	while(i<40)
		{System.out.print((evens=evens+2) + " ");
		i++;
		}
	if(i==40)
		{System.out.println("80\n");
		evens=evens+2;
		i++;
		}
	while(i<50)
		{System.out.print((evens=evens+2) + " ");
		i++;
		}
	if(i==50)
		{System.out.println("100");
		evens=evens+2;
		i++;
		}
	}

}
