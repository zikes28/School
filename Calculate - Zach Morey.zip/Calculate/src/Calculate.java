import javax.swing.JOptionPane;

public class Calculate 
{

	public static void main(String[] args) 
	{
				//declaring integer strings and option string for input
				String strInt1;
				String strInt2;
				String strOption;
			//prompting input for 2 integers and option choice
			strInt1=JOptionPane.showInputDialog("First integer: ");
			strInt2=JOptionPane.showInputDialog("Second integer: ");
			strOption=JOptionPane.showInputDialog("Enter 1, 2 , 3, or 4: ");
				//converting strings to ints
				int one = Integer.parseInt(strInt1);
				int two = Integer.parseInt(strInt2);
				int option = Integer.parseInt(strOption);
			//1: addition
			if(option==1)
					JOptionPane.showMessageDialog(null, one+two);
			//2: subtraction
			else
				if(option==2)
					JOptionPane.showMessageDialog(null, one-two);
			//3: multiplication
			else
				if(option==3)
					JOptionPane.showMessageDialog(null, one*two);
			//if user enters second int as 0
			else
				if(option==4 && two==0)
					JOptionPane.showMessageDialog(null, "no...");
			//4: division- negating two=0
			else 
				if(option==4 && two!=0)
					JOptionPane.showMessageDialog(null, one/two);
			//if user enters number other than 1, 2, 3, or 4
			else
					JOptionPane.showMessageDialog(null, "Bruh... don't even try");
	}

}
