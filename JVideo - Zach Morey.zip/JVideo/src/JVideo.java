import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JVideo extends JFrame implements ItemListener {
JComboBox movie=new JComboBox();
JLabel movieList=new JLabel("De Movie List boii");
JLabel aMovie=new JLabel("The Colliest Video Store maiiiin(dont ask questions");
JTextField priceField=new JTextField(10);
	int[] movieP={1,2,3,2,3,2,2};
	String output;
	int FavorNum;
	
	public JVideo(){
		super("The Cooliest Video Store");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
	add(aMovie);
	movie.addItemListener(this);
	add(movieList);
	
		movie.addItem("yo face");
		movie.addItem("no");
		movie.addItem("yes");
		movie.addItem("josh morey the buffalo");
		movie.addItem("brett the cool guy");
		movie.addItem("jcole the other cool guy");
		movie.addItem("lenses");
		
	add(movie);
	add(priceField);
	}
	
	public static void main(String[] args){
		
		JVideo aName = new JVideo();
		aName.setSize(400,150);
		aName.setVisible(true);
	}
	
	public void itemStateChanged (ItemEvent e){
		Object source = e.getSource();
		if (source==movie){
			int favorNum = movie.getSelectedIndex();
			output="Movie Price $"+movieP[favorNum]+".00";
			priceField.setText(output);
			}

	}

}
