import java.util.Scanner;
public class DigitalClock
{

	public static void main(String[] args)
	{	
		Scanner keyboard = new Scanner(System.in);
		
		int seconds = 0;
		int minutes = 0;
		int hours = 0;
		int hourstocount;
		
		System.out.println("Input Aamount of time (hours) you want da ting to count: ");
		hourstocount = keyboard.nextInt();
				do 
				{
					minutes=0;
					do
					{
						seconds=0;
						do
						{			
							try
							{
							Thread.sleep(5);
							}
							catch(InterruptedException e)
							{
							e.printStackTrace();
							}
							System.out.println(hours + ":" + minutes + ":" + seconds);
							seconds++;
						}while(seconds<60);
						minutes++;
					}while(minutes<60);
					hours++;
				}while(hours<hourstocount);

			}

}
