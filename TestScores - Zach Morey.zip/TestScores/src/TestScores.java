import java.util.Scanner;

public class TestScores
{

	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int testScore = 1;
		int amount = 0;
		int total = 0;
		double avrg;
		
		
		
		System.out.println("Input Test Score(enter scores from 1 to 100. Enter 0 when finished): ");

		while(testScore != 0)
		{
			testScore = keyboard.nextInt();
			if(testScore > 100) {
					System.out.println("number has to be under 100");
			} else if(testScore != 0) {
					total += testScore;
					amount++;	
			}
		}
				
				avrg = total/amount;
				System.out.println("Total points: " + total + "\nAverage: " + avrg);
}
}
