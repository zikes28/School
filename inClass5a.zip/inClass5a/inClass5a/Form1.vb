﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sales = 20
        Dim salesDiscount = 0.08
        Dim age = InputBox("enter age")
        Dim residence = InputBox("enter state")
        If age > 64 And residence = "minnesota" Then
            Label1.Text = "your discount off $20 is $" & salesDiscount * sales
        Else
            Label1.Text = "you dont recieve a discount.. sales is $" & sales
        End If
    End Sub
End Class
