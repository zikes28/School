﻿Option Explicit On
Option Strict On
Option Infer On
Public Class frmMain
    Const TAX_RATE As Double = 0.07
    Private strSalesPerson As String
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        strSalesPerson = InputBox("enter your name", "name")


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtHatsPrice.Clear()
        txtHatsQty.Clear()
        txtGlovesQty.Clear()
        txtGlovesPrice.Clear()
        txtScarvesPricce.Clear()
        txtScarvesQty.Clear()
        txtHatsPrice.Focus()
        lblTotalPrice.Text = ""
        lblTotalQty.Text = ""
        lblRecite.Text = "Reciept:"
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim total = (Val(txtHatsPrice.Text) * Val(txtHatsQty.Text) + Val(txtGlovesPrice.Text) * Val(txtGlovesQty.Text) + Val(txtScarvesPricce.Text) * Val(txtScarvesQty.Text))
        lblTotalPrice.Text = total.ToString
        Dim Qty = (Val(txtHatsQty.Text) + Val(txtGlovesQty.Text) + Val(txtScarvesQty.Text))
        lblTotalQty.Text = Qty.ToString
        txtGlovesExt.Text = (Val(txtGlovesPrice.Text) * Val(txtGlovesQty.Text)).ToString
        txtHatsExt.Text = (Val(txtHatsPrice.Text) * Val(txtHatsQty.Text)).ToString
        txtScarvesExt.Text = (Val(txtScarvesPricce.Text) * Val(txtScarvesQty.Text)).ToString
        lblRecite.Text = "thanks for your puechase" & vbCrLf & "sales tax was " & (Convert.ToString(Val(lblTotalPrice.Text) * TAX_RATE)) & vbCrLf & strSalesPerson & ", Up north Goods"
    End Sub
End Class
