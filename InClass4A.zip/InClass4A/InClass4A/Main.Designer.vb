﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtHatsQty = New System.Windows.Forms.TextBox()
        Me.txtGlovesQty = New System.Windows.Forms.TextBox()
        Me.txtScarvesQty = New System.Windows.Forms.TextBox()
        Me.lblTotalQty = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtHatsPrice = New System.Windows.Forms.TextBox()
        Me.txtGlovesPrice = New System.Windows.Forms.TextBox()
        Me.txtScarvesPricce = New System.Windows.Forms.TextBox()
        Me.lblTotalPrice = New System.Windows.Forms.Label()
        Me.txtHatsExt = New System.Windows.Forms.TextBox()
        Me.txtGlovesExt = New System.Windows.Forms.TextBox()
        Me.txtScarvesExt = New System.Windows.Forms.TextBox()
        Me.lblRecite = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(197, 168)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(59, 24)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(121, 168)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(60, 27)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clearr"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(43, 168)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(72, 22)
        Me.btnCalc.TabIndex = 2
        Me.btnCalc.Text = "Calc"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(40, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Hats"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(34, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Gloves"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 90)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Scarves"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 123)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Total"
        '
        'txtHatsQty
        '
        Me.txtHatsQty.Location = New System.Drawing.Point(95, 21)
        Me.txtHatsQty.Name = "txtHatsQty"
        Me.txtHatsQty.Size = New System.Drawing.Size(48, 20)
        Me.txtHatsQty.TabIndex = 7
        '
        'txtGlovesQty
        '
        Me.txtGlovesQty.Location = New System.Drawing.Point(87, 52)
        Me.txtGlovesQty.Name = "txtGlovesQty"
        Me.txtGlovesQty.Size = New System.Drawing.Size(55, 20)
        Me.txtGlovesQty.TabIndex = 8
        '
        'txtScarvesQty
        '
        Me.txtScarvesQty.Location = New System.Drawing.Point(86, 87)
        Me.txtScarvesQty.Name = "txtScarvesQty"
        Me.txtScarvesQty.Size = New System.Drawing.Size(56, 20)
        Me.txtScarvesQty.TabIndex = 9
        '
        'lblTotalQty
        '
        Me.lblTotalQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalQty.Location = New System.Drawing.Point(83, 118)
        Me.lblTotalQty.Name = "lblTotalQty"
        Me.lblTotalQty.Size = New System.Drawing.Size(58, 17)
        Me.lblTotalQty.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(91, 1)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Quantity"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(173, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Price"
        '
        'txtHatsPrice
        '
        Me.txtHatsPrice.Location = New System.Drawing.Point(163, 18)
        Me.txtHatsPrice.Name = "txtHatsPrice"
        Me.txtHatsPrice.Size = New System.Drawing.Size(55, 20)
        Me.txtHatsPrice.TabIndex = 13
        '
        'txtGlovesPrice
        '
        Me.txtGlovesPrice.Location = New System.Drawing.Point(158, 49)
        Me.txtGlovesPrice.Name = "txtGlovesPrice"
        Me.txtGlovesPrice.Size = New System.Drawing.Size(59, 20)
        Me.txtGlovesPrice.TabIndex = 14
        '
        'txtScarvesPricce
        '
        Me.txtScarvesPricce.Location = New System.Drawing.Point(157, 89)
        Me.txtScarvesPricce.Name = "txtScarvesPricce"
        Me.txtScarvesPricce.Size = New System.Drawing.Size(60, 20)
        Me.txtScarvesPricce.TabIndex = 15
        '
        'lblTotalPrice
        '
        Me.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPrice.Location = New System.Drawing.Point(155, 117)
        Me.lblTotalPrice.Name = "lblTotalPrice"
        Me.lblTotalPrice.Size = New System.Drawing.Size(62, 17)
        Me.lblTotalPrice.TabIndex = 16
        '
        'txtHatsExt
        '
        Me.txtHatsExt.Location = New System.Drawing.Point(243, 18)
        Me.txtHatsExt.Name = "txtHatsExt"
        Me.txtHatsExt.ReadOnly = True
        Me.txtHatsExt.Size = New System.Drawing.Size(45, 20)
        Me.txtHatsExt.TabIndex = 18
        '
        'txtGlovesExt
        '
        Me.txtGlovesExt.Location = New System.Drawing.Point(243, 49)
        Me.txtGlovesExt.Name = "txtGlovesExt"
        Me.txtGlovesExt.ReadOnly = True
        Me.txtGlovesExt.Size = New System.Drawing.Size(45, 20)
        Me.txtGlovesExt.TabIndex = 19
        '
        'txtScarvesExt
        '
        Me.txtScarvesExt.Location = New System.Drawing.Point(243, 83)
        Me.txtScarvesExt.Name = "txtScarvesExt"
        Me.txtScarvesExt.ReadOnly = True
        Me.txtScarvesExt.Size = New System.Drawing.Size(45, 20)
        Me.txtScarvesExt.TabIndex = 20
        '
        'lblRecite
        '
        Me.lblRecite.AutoSize = True
        Me.lblRecite.Location = New System.Drawing.Point(240, 117)
        Me.lblRecite.Name = "lblRecite"
        Me.lblRecite.Size = New System.Drawing.Size(44, 13)
        Me.lblRecite.TabIndex = 21
        Me.lblRecite.Text = "Reciept"
        '
        'frmMain
        '
        Me.AcceptButton = Me.btnCalc
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(470, 207)
        Me.Controls.Add(Me.lblRecite)
        Me.Controls.Add(Me.txtScarvesExt)
        Me.Controls.Add(Me.txtGlovesExt)
        Me.Controls.Add(Me.txtHatsExt)
        Me.Controls.Add(Me.lblTotalPrice)
        Me.Controls.Add(Me.txtScarvesPricce)
        Me.Controls.Add(Me.txtGlovesPrice)
        Me.Controls.Add(Me.txtHatsPrice)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblTotalQty)
        Me.Controls.Add(Me.txtScarvesQty)
        Me.Controls.Add(Me.txtGlovesQty)
        Me.Controls.Add(Me.txtHatsQty)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "frmMain"
        Me.Text = "Up North Goods"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtHatsQty As TextBox
    Friend WithEvents txtGlovesQty As TextBox
    Friend WithEvents txtScarvesQty As TextBox
    Friend WithEvents lblTotalQty As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtHatsPrice As TextBox
    Friend WithEvents txtGlovesPrice As TextBox
    Friend WithEvents txtScarvesPricce As TextBox
    Friend WithEvents lblTotalPrice As Label
    Friend WithEvents txtHatsExt As TextBox
    Friend WithEvents txtGlovesExt As TextBox
    Friend WithEvents txtScarvesExt As TextBox
    Friend WithEvents lblRecite As Label
End Class
