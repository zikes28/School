import javax.swing.JOptionPane;

public class calcTuition 

{

	public static void main(String[] args)
	
	{
		String creditString;
		int credit;
		creditString = JOptionPane.showInputDialog(null, "Enter amount of credits:","Credits",JOptionPane.INFORMATION_MESSAGE);
		credit = Integer.parseInt(creditString);
		Tuition(credit);
	}
	public static void Tuition(int totCredits)
	{
		final int Cost = 300;
		int totalCost = totCredits * Cost;
		JOptionPane.showMessageDialog(null,  "Total cost is $"+totalCost);
				
	}

}
