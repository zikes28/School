import java.text.NumberFormat;

import javax.swing.JOptionPane;

public class fahrenheitToCelsius
{

	public static void main(String[] args) 
	{
		//declaring Fahrenheit String
		String Fdegree;
		
		//Input-Dialog box
		Fdegree = JOptionPane.showInputDialog(null,"Input a degree in Fahrenheit:");
		
		//converting string var to int
		int IntFdegree = Integer.parseInt(Fdegree);
		
		//Introducing number vars + Celsius calculation
		double Multiplyer = 5/9;
		int Subtractioner = 32;
		double Cdegree = (IntFdegree-Subtractioner)*Multiplyer;
		
		//output
		JOptionPane.showMessageDialog(null, Fdegree + " degrees in Fahrenheit is equal to\n" + Cdegree + " degrees in Celcuis");
	}

}
