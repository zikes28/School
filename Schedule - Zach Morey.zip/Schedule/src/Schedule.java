import javax.swing.JOptionPane;

public class Schedule 
{

	public static void main(String[] args) 
	{
		boolean done = false; 
		String courseTitle[][] = { 
				{"popcorn studies", "Th 9:00pm(movie time)"},
				{"socks and their uses", "Wed 2:00pm"},
				{"how to operate a brand new pencil", "Mon 8:00am"},
				{"the party hat: a perfect tool", "Fri 3:00pm"}
							};	
				
				while(done==false)
				{
					String input = JOptionPane.showInputDialog(null, "Input the course name and you will recieve the day of the week and time that corroponds: ");
					for(int i = 0; i<4; i++)
					{
						if(input.equals(courseTitle[i][0]))
						{
						JOptionPane.showMessageDialog(null, courseTitle[i][1]);
						done=true;
						}
					}
					if(done==false)
						JOptionPane.showMessageDialog(null, "no...\ntry again you failiure...");
			}
			
		
	}
}


