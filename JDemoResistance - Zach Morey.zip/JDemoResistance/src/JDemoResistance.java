import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class JDemoResistance extends JFrame implements ActionListener {
	Font headlineFont = new Font("Arial", Font.BOLD, 50);
	Font headlineFont2 = new Font("Arial", Font.BOLD, 40);
	Font headlineFont3 = new Font("Arial", Font.BOLD, 30);
	Font headlineFont4 = new Font("Arial", Font.BOLD, 20);
	Font headlineFont5 = new Font("Arial", Font.BOLD, 10);
		JLabel label = new JLabel("They slipped on a MISPLACED banana peel");
		JLabel label2 = new JLabel("My dog bit them");
		JLabel label3 = new JLabel("They hate me personally");
		JLabel label4 = new JLabel("The commercial is stupid");
		JLabel label5 = new JLabel("The quality sucks");
		JButton button = new JButton("PRESS ME!");
		
	public JDemoResistance()
	{
		super("Frame");
		setSize(750,750);
		setLayout(new FlowLayout());
		label.setFont(headlineFont);
		label2.setFont(headlineFont2);
		label3.setFont(headlineFont3);
		label4.setFont(headlineFont4);
		label5.setFont(headlineFont5);
		add(label);
		add(label2);
		add(label3);
		add(label4);
		add(label5);
		add(button);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		button.addActionListener(this);
	}
	int clicks = 0;
	public void actionPerformed(ActionEvent e){
		clicks++;
        switch (clicks){
            case 1:
                label.setVisible(false);
                break;
            case 2:
            	label2.setVisible(false);
                break;
            case 3:
           	    label3.setVisible(false);
           	    break;
            case 4:
           	    label4.setVisible(false);
           	    break;
            case 5:
           	    label5.setVisible(false);
           	    break;
           

	}
	}
}

