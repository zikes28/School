
public class demo {
	public static void main(String[] args) {
		JDemoResistance frame = new JDemoResistance();
		frame.setVisible(true);
		}
}
